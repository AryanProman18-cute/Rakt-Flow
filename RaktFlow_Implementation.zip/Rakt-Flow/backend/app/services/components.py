from datetime import datetime, timedelta
from uuid import UUID
from fastapi import HTTPException

# Conservative operational defaults only. A verified facility must apply its
# licensed SOP, additive solution, storage temperature, irradiation and local
# regulation before relying on an expiry timestamp.
DEFAULT_SHELF_LIFE_DAYS = {
    "WHOLE_BLOOD": 35,
    "PRBC": 42,
    "RBC": 42,
    "SDP": 5,
    "RDP": 5,
    "PLATELETS": 5,
    "FFP": 365,
    "CRYOPRECIPITATE": 365,
}

TEMPERATURE_RANGES_C = {
    "WHOLE_BLOOD": (1.0, 6.0),
    "PRBC": (1.0, 6.0),
    "RBC": (1.0, 6.0),
    "SDP": (20.0, 24.0),
    "RDP": (20.0, 24.0),
    "PLATELETS": (20.0, 24.0),
    "FFP": (-40.0, -18.0),
    "CRYOPRECIPITATE": (-40.0, -18.0),
}


def default_expiry(component_type: str, prepared_at: datetime) -> datetime:
    days = DEFAULT_SHELF_LIFE_DAYS.get(component_type.upper(), 35)
    return prepared_at + timedelta(days=days)


def temperature_status(component_type: str, value: float) -> str:
    limits = TEMPERATURE_RANGES_C.get(component_type.upper())
    if limits is None:
        return "REVIEW_REQUIRED"
    low, high = limits
    return "IN_RANGE" if low <= value <= high else "OUT_OF_RANGE_REVIEW_REQUIRED"


async def validate_separation_of_duties(
    component_id: UUID,
    user_id: UUID,
    session: AsyncSession,
) -> None:
    """Ensure no single user can both create/collect and independently receive/finalize the same unit.

    Controls:
    - A user who dispatched a cold-chain handover may not also be the recorded receiver.
    - A user who collected a component may not also independently finalize its receipt
      for the same unit.
    - Raises HTTPException 403 if the same user attempts both roles for the same component.
    """

    # Check if user dispatched a handover for this component
    handover_dispatched = await session.scalar(
        select(ColdChainHandover).where(
            ColdChainHandover.component_id == component_id,
            ColdChainHandover.handed_over_by_user_id == user_id,
        )
    )
    # Check if user received a handover for this component
    # Note: field name is received_by_user_id (not received_by_user_user_id)
    handover_received = await session.scalar(
        select(ColdChainHandover).where(
            ColdChainHandover.component_id == component_id,
            ColdChainHandover.received_by_user_id == user_id,
        )
    )
    if handover_dispatched and handover_received:
        raise HTTPException(
            status.HTTP_403_FORBIDDEN,
            "Separation of duties violation: same user cannot both dispatch and receive this handover",
        )
